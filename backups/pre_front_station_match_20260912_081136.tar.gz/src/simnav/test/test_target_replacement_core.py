#!/usr/bin/env python3

import unittest

from coverage_explorer_core import target_replacement_gain_ok


class TargetReplacementGainTest(unittest.TestCase):
    def test_better_target_replaces_without_stall(self):
        self.assertTrue(
            target_replacement_gain_ok(6.33, 2.36, progress_age=0.0)
        )

    def test_equal_target_does_not_replace_without_stall(self):
        self.assertFalse(
            target_replacement_gain_ok(6.33, 6.33, progress_age=0.0)
        )

    def test_higher_gain_margin_is_honoured(self):
        # 1.30x of 6.33 is 8.23, so 8.10 is not enough while fresh.
        self.assertFalse(
            target_replacement_gain_ok(8.10, 6.33, progress_age=0.0)
        )
        self.assertTrue(
            target_replacement_gain_ok(8.30, 6.33, progress_age=0.0)
        )

    def test_stall_still_refuses_a_much_worse_target(self):
        # The run44 flip-flop: 2.36 must never steal the lock from 6.33,
        # even after the active target has stalled for a long time.
        self.assertFalse(
            target_replacement_gain_ok(
                2.36, 6.33, progress_age=120.0, replace_stall=8.0
            )
        )

    def test_stall_allows_a_moderately_worse_escape_hatch(self):
        # Half the active gain (0.50 floor) is still accepted while stalled,
        # so an unreachable-but-high-gain target does not dead-lock.
        self.assertTrue(
            target_replacement_gain_ok(
                3.20, 6.33, progress_age=120.0, replace_stall=8.0
            )
        )
        self.assertFalse(
            target_replacement_gain_ok(
                3.00, 6.33, progress_age=120.0, replace_stall=8.0
            )
        )

    def test_stall_threshold_boundary(self):
        self.assertFalse(
            target_replacement_gain_ok(4.00, 6.33, progress_age=7.9)
        )
        self.assertTrue(
            target_replacement_gain_ok(4.00, 6.33, progress_age=8.0)
        )

    def test_zero_active_gain_is_replaced_by_any_positive_gain(self):
        self.assertTrue(target_replacement_gain_ok(0.01, 0.0, progress_age=0.0))
        self.assertFalse(target_replacement_gain_ok(0.0, 0.0, progress_age=0.0))


if __name__ == "__main__":
    unittest.main()
