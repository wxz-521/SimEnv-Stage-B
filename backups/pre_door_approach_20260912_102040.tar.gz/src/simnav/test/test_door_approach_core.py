#!/usr/bin/env python3
"""Regression tests for the door-approach fallback.

run50 floor 0 stalled in the corridor: four actionable portals, every candidate
rejected as ``path_unreachable``, a zero-cell verified door band, and the robot
standing 8.5 m short of the door with no corridor frontier left.  Entering a
room that has never been seen cannot be planned, because the staged crossing
ends at a point inside that room which is unknown by definition -- so the robot
has to be sent to the door first.
"""

import unittest

from coverage_explorer_core import door_approach_is_new


class DoorApproachIsNewTest(unittest.TestCase):
    def test_unvisited_viewpoint_is_dispatched(self):
        self.assertTrue(door_approach_is_new((5.0, 0.0), [], 0.7))

    def test_already_visited_viewpoint_is_not_re_dispatched(self):
        # Standing in front of the door again must not become an endless
        # shuttle once the room has proved unroutable from there.
        self.assertFalse(door_approach_is_new((5.0, 0.0), [(5.1, 0.1)], 0.7))

    def test_distant_visited_viewpoints_do_not_block(self):
        self.assertTrue(door_approach_is_new((5.0, 0.0), [(9.0, 0.0)], 0.7))

    def test_radius_is_respected(self):
        visited = [(5.0, 0.5)]
        self.assertFalse(door_approach_is_new((5.0, 0.0), visited, 0.7))
        self.assertTrue(door_approach_is_new((5.0, 0.0), visited, 0.4))

    def test_missing_visited_list_is_tolerated(self):
        self.assertTrue(door_approach_is_new((5.0, 0.0), None, 0.7))


if __name__ == "__main__":
    unittest.main()
