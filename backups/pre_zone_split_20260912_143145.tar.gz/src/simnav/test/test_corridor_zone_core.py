#!/usr/bin/env python3
"""Regression tests for corridor-half zoning.

Rooms are explored one corridor half at a time: the near half plus its opposing
room pair form one zone, the far half the next.  Inside a zone the robot may move
freely between the half-corridor and its rooms, which is what removes the
"entered the room, no candidate left, stood still" failure - run55 floor 0 locked
ROOM_R_3, produced no candidate at all and stood 1 m from its door until the
position watchdog fired.  Per-room topology and coverage accounting are
unchanged; only what may be dispatched changes.
"""

import unittest

from coverage_explorer_core import (
    RoomPortal,
    active_zone,
    zone_admits,
    zone_of_along,
    zone_split_along,
)


class ZoneSplitTest(unittest.TestCase):
    def test_split_is_the_midpoint_of_the_detected_doorways(self):
        portals = [
            RoomPortal("ROOM_L_15", "L", 15.0, 1.1, 0.9),
            RoomPortal("ROOM_L_43", "L", 43.0, 1.1, 0.9),
        ]
        self.assertAlmostEqual(zone_split_along(portals, 35.0), 29.0)

    def test_single_doorway_falls_back_to_half_the_task_extent(self):
        portals = [RoomPortal("ROOM_L_15", "L", 15.0, 1.1, 0.9)]
        self.assertAlmostEqual(zone_split_along(portals, 30.0), 15.0)

    def test_no_doorways_is_tolerated(self):
        self.assertAlmostEqual(zone_split_along([], 30.0), 15.0)


class ZoneOfAlongTest(unittest.TestCase):
    def test_near_and_far(self):
        self.assertEqual(zone_of_along(5.0, 20.0), "A")
        self.assertEqual(zone_of_along(35.0, 20.0), "B")

    def test_pair_straddling_the_midpoint_stays_near(self):
        # A doorway inside the band must not be torn into the far zone, or an
        # opposing pair would be split across two zones.
        self.assertEqual(zone_of_along(21.0, 20.0, band=1.5), "A")
        self.assertEqual(zone_of_along(22.5, 20.0, band=1.5), "B")

    def test_zone_admits_only_the_active_half(self):
        self.assertTrue(zone_admits(5.0, 20.0, "A"))
        self.assertFalse(zone_admits(35.0, 20.0, "A"))
        self.assertTrue(zone_admits(35.0, 20.0, "B"))


class ActiveZoneTest(unittest.TestCase):
    def setUp(self):
        self.portals = [
            RoomPortal("ROOM_L_15", "L", 8.0, 1.1, 0.9),
            RoomPortal("ROOM_R_15", "R", 8.5, -1.1, 0.9),
            RoomPortal("ROOM_L_43", "L", 33.0, 1.1, 0.9),
            RoomPortal("ROOM_R_43", "R", 33.5, -1.1, 0.9),
        ]
        self.split = zone_split_along(self.portals, 35.0)

    def test_near_zone_runs_first(self):
        self.assertEqual(active_zone(self.portals, (), self.split), "A")

    def test_far_zone_waits_for_every_near_room(self):
        self.assertEqual(
            active_zone(self.portals, ("ROOM_L_15",), self.split), "A"
        )

    def test_far_zone_opens_once_the_near_half_is_complete(self):
        self.assertEqual(
            active_zone(
                self.portals, ("ROOM_L_15", "ROOM_R_15"), self.split
            ),
            "B",
        )

    def test_everything_complete_defaults_to_the_near_zone(self):
        self.assertEqual(
            active_zone(
                self.portals,
                ("ROOM_L_15", "ROOM_R_15", "ROOM_L_43", "ROOM_R_43"),
                self.split,
            ),
            "A",
        )


if __name__ == "__main__":
    unittest.main()
