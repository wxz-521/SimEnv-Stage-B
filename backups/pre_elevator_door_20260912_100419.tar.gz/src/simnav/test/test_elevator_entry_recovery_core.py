#!/usr/bin/env python3
"""Regression tests for elevator car-door handling.

run49 completed floors 0 and 1 with 4 rooms each and then failed the whole
mission on the floor-1 return leg:
``ELEVATOR_PATH_BLOCKED_AFTER_0.93M`` with a 0.27 m front clearance, 7 cm short
of ``minimum_entry_progress``.  The layout marks ``elevator_floor_0`` as
initially open and ``elevator_floor_1`` as initially closed, and the node only
ever called ``/set_door_state`` for the main entrance.
"""

import unittest

from elevator_transition_core import (
    elevator_door_id,
    entry_blocked_retry_allowed,
)


class EntryBlockedRetryTest(unittest.TestCase):
    def test_short_travel_block_is_retried_while_budget_remains(self):
        # The exact run49 numbers: 0.93 m travelled against a 1.0 m threshold.
        self.assertTrue(
            entry_blocked_retry_allowed(0.93, 1.0, retries=0, retry_limit=4)
        )

    def test_post_threshold_block_is_containment_not_a_retry(self):
        # At or beyond the threshold the caller treats the stop as a completed
        # entry, so no retry may be requested.
        self.assertFalse(
            entry_blocked_retry_allowed(1.0, 1.0, retries=0, retry_limit=4)
        )
        self.assertFalse(
            entry_blocked_retry_allowed(2.4, 1.0, retries=3, retry_limit=4)
        )

    def test_retry_budget_is_finite(self):
        self.assertTrue(
            entry_blocked_retry_allowed(0.4, 1.0, retries=3, retry_limit=4)
        )
        self.assertFalse(
            entry_blocked_retry_allowed(0.4, 1.0, retries=4, retry_limit=4)
        )

    def test_zero_budget_preserves_the_old_fail_fast_behaviour(self):
        self.assertFalse(
            entry_blocked_retry_allowed(0.93, 1.0, retries=0, retry_limit=0)
        )


class ElevatorDoorIdTest(unittest.TestCase):
    def test_floor_ids_match_the_scene_layout(self):
        self.assertEqual(elevator_door_id(0), "elevator_floor_0")
        self.assertEqual(elevator_door_id(1), "elevator_floor_1")
        self.assertEqual(elevator_door_id(2), "elevator_floor_2")

    def test_float_floor_index_is_accepted(self):
        self.assertEqual(elevator_door_id(1.0), "elevator_floor_1")

    def test_prefix_can_be_overridden(self):
        self.assertEqual(
            elevator_door_id(2, "lift_door"), "lift_door_2"
        )


if __name__ == "__main__":
    unittest.main()
